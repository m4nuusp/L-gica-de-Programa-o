package vetex.pkg5;

import java.util.Scanner;

public class Vetex5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] vet1 = new int[100];
        int tamanho = 5, total = 0;
        int[] vet2 = new int[tamanho];

        for (int i = 0; i < 100; i++) {
            vet1[i] = (int) (Math.random() * 10);

        }
        for (int j = 0; j < 5; j++) {
            System.out.print("Número " + (j + 1) + ": ");
            vet2[j] = teclado.nextInt();
        }

        System.out.println("\n--- RESULTADO DA BUSCA ---");

        for (int j = 0; j < 5; j++) {
            total = 0;

            for (int i = 0; i < 100; i++) {
                if (vet1[i] == vet2[j]) {
                    System.out.print(i + " ");
                    total++;
                }
            }

            if (total == 0) {
                System.out.print("Não encontrado no primeiro vetor.");
            }
            System.out.println();
        }
    }
}
