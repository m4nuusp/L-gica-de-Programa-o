package vetex.pkg6;

import java.util.Scanner;

public class Vetex6 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho =5;
        String []veiculos = new String[tamanho];
        double []consumomedio = new double [tamanho];
        double valorcombustivel, custo780km, maisecon, menosecon;
        String nomemaisecon, nomemenosecon;
        
        System.out.println("Qual o valor do combustivel?");
        valorcombustivel = teclado.nextDouble();
        teclado.nextLine();
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o modelo do veiculo " + (i + 1) + ":");
            veiculos[i] = teclado.nextLine();
            
            System.out.println("Informe o consumo medio de gasolina (km/l):");
            consumomedio[i] = teclado.nextDouble(); 
            teclado.nextLine();
        }
        
        maisecon = consumomedio[0];
        menosecon = consumomedio [0];
        nomemaisecon = veiculos[0];
        nomemenosecon = veiculos[0];
        
        
        
        for (int i = 0; i < tamanho; i++) {
            if (consumomedio[i]>maisecon) {
                maisecon=consumomedio[i];
                nomemaisecon=veiculos[i];
            }
            if (consumomedio[i]<menosecon) {
                menosecon = consumomedio[i];
                nomemenosecon = veiculos[i];
            }
        }
        
        for (int i = 0; i < tamanho; i++) {
           custo780km = 780/consumomedio[i];
           custo780km = custo780km * valorcombustivel;
            System.out.println("O carro " + veiculos[i] + " gastara " + custo780km);
        } 
        
         System.out.println("O veículo mais econômico é o " + nomemaisecon + " com " + maisecon + " km/l.");
        System.out.println("O veículo menos econômico é o " + nomemenosecon + " com " + menosecon + " km/l.");
        
        }
        }
        
        
    


