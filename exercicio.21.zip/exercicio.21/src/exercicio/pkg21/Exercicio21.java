package exercicio.pkg21;

import java.util.Scanner;

public class Exercicio21 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int comeco , termino, duracao;
        
        System.out.println("digite a hora que começou:");
        comeco = teclado.nextInt();
        System.out.println("digite a hora que terminou:");
        termino = teclado.nextInt();
        if (termino <= comeco) {
            duracao = 24 + termino - comeco;
            System.out.println("Duração: " + duracao);
        } else {
            duracao = termino - comeco;
            System.out.println("Duração: " + duracao);
        }
    }

}
