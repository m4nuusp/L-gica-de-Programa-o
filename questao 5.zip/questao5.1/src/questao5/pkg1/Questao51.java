
package questao5.pkg1;
import java.util.Scanner;

public class Questao51 {

   
    public static void main(String[] args) {
         Scanner teclado = new Scanner(System.in);
//5) Apresente a série de Fibonacci até o enésimo termo informado pelo usuário:
        int enesimo, limite = 3, num1 = 0, num2 = 0, resultado;

        System.out.println("digite o enesimo digito do padrao de fibonacci");
        enesimo = teclado.nextInt();

        while (limite <= enesimo) {
            if (num1 == 1) {

                System.out.println(num1);
                num1 = num1;

            }
            if (num1 == 0) {

                System.out.println(num1);
                num1 = 1;

            }

            resultado = num1 + num2;
            num2 = num1;
            num1 = resultado;

            limite++;
            System.out.println(resultado);

        }
    }
    
}
