
package ex.pkg26;

import java.util.Scanner;
public class Ex26 {

  
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int homem1 , homem2, mulher1, mulher2, soma, produto;
        
        System.out.println("Digite a idade do primeiro homem:");
        homem1 = teclado.nextInt();
        System.out.println("Digite a idade do segundo homem:");
        homem2 = teclado.nextInt();
        System.out.println("Digite a idade da primeira mulher:");
        mulher1 = teclado.nextInt();
        System.out.println("Digite a idade da segunda mulher:");
        mulher2 = teclado.nextInt();
        
        if (homem1>homem2) {
            if (mulher1>mulher2) {
                soma = homem1 + mulher2;
                produto = homem2 * mulher1;
                System.out.println("A soma da idade e " + soma + " e o produto e " + produto);
            } else {
                soma = homem1 + mulher1;
                produto = homem2* mulher2;
                System.out.println("A soma da idade e " + soma + " e o produto e " + produto);
            }
        } else {
            if (mulher1>mulher2) {
                soma = homem2 + mulher2;
                produto = homem1 * mulher1;
                System.out.println("A soma da idade e " + soma + " e o produto e " + produto);
            } else {
                soma = homem2 + mulher1;
                produto = homem1 * mulher2;
                System.out.println("A soma da idade e " + soma + " e o produto e " + produto);
            }
        }
    }
    
}
