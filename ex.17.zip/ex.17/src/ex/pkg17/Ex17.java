package ex.pkg17;

import java.util.Scanner;

public class Ex17 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double salarioA, salarioN, dif;
        int codigo;

        System.out.println("Insira o código do cargo:");
        codigo = teclado.nextInt();
        System.out.println("Insira o salario");
        salarioA = teclado.nextDouble();
        if (codigo == 101) {
            salarioN = salarioA * 1.1;
            dif = salarioN - salarioA;
            System.out.println("Salário Antigo: " + salarioA + " Salário Novo:" + salarioN + " Diferença: " + dif);
        } else {
            if (codigo == 102) {
                salarioN = salarioA * 1.2;
                dif = salarioN - salarioA;
                System.out.println("Salário Antigo: " + salarioA + " Salário Novo:" + salarioN + " Diferença: " + dif);
            } else {
                if (codigo == 103) {
                    salarioN = salarioA * 1.3;
                    dif = salarioN - salarioA;
                    System.out.println("Salário Antigo: " + salarioA + " Salário Novo:" + salarioN + " Diferença: " + dif);
                } else {

                    salarioN = salarioA * 1.4;
                    dif = salarioN - salarioA;
                    System.out.println("Salário Antigo: " + salarioA + " Salário Novo:" + salarioN + " Diferença: " + dif);
                }
            }
        }

    }

}
