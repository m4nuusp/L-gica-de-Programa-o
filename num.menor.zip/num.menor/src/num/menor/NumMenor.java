package num.menor;

import java.util.Scanner;
public class NumMenor {

   
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int num1 , num2 ,num3;
        System.out.println("digite o primeiro numero");
      num1 =  teclado.nextInt();
        System.out.println("digite o segundo numero");
        num2 = teclado.nextInt();
        System.out.println("digite o terceiro numero");
        num3 = teclado.nextInt();
        
        if (num1 < num2) {
            if (num1<num3) {
                System.out.println("menor numero " + num1);
            } else{
                System.out.println("menor numero " + num3);
            }
            
        } else  {
            if (num1 <num3) {
                System.out.println("menor numero " + num2);
            } else {
                if (num2 < num3) {
                    System.out.println("menor numero " + num2);
                } else{
                    System.out.println("menor numero " + num3);
                }
            }
        }    
        
    }
    
}
