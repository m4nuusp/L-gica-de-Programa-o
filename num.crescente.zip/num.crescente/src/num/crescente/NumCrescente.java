package num.crescente;

import java.util.Scanner;

public class NumCrescente {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int num1, num2;
        System.out.println("dIGITE O PRIMEIRO NÚMERO:");
        num1 = teclado.nextInt();
        System.out.println("digite o segundo nùmero:");
        num2 = teclado.nextInt();

        if (num1 > num2) {
            System.out.println(num2 + "," + num1);
        } else {
            System.out.println(num1 + "," + num2);
        }

    }

}
