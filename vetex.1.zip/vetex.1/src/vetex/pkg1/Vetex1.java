package vetex.pkg1;

import java.util.Scanner;

public class Vetex1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int resto;
        int[] vet_num = new int[5];

        for (int i = 0; i < 5; i++) {
            System.out.println("Digite um numero");
            vet_num[i] = teclado.nextInt();
        }
        for (int i = 0; i < 5; i++) {
            System.out.println((i + 1) + "o. valor é " + vet_num[i]);

        }
        for (int i = 0; i < 5; i++) {
            if (vet_num[i] % 2 ==0) {
                System.out.println( "os numeros pares sao " + vet_num[i]);
            }
        }

    }
}
