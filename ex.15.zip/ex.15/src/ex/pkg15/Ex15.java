package ex.pkg15;

import java.util.Scanner;

public class Ex15 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double saldo, credito;
        System.out.println("Insira seu saldo");
        saldo = teclado.nextDouble();
        if (saldo < 201) {
            System.out.println("Saldo: " + saldo + "Credito: Nenhum");
        } else {
            if (saldo < 401) {
                credito = saldo * 0.2;
                System.out.println("Saldo:" + saldo + "Credito:" + credito);
            } else {
                if (saldo < 601) {
                    credito = saldo * 0.3;
                    System.out.println("Saldo:" + saldo + "Credito:" + credito);
                } else {
                    credito = saldo * 1.4;
                    System.out.println("Saldo:" + saldo + "Credito:" + credito);
                }
            }
        }
    }

}
