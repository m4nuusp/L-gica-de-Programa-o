
package ex.pkg25;
import java.util.Scanner;

public class Ex25 {

    
    public static void main(String[] args) {
      Scanner teclado = new Scanner (System.in)  ;
      int time1, time2, gol1, gol2;
        System.out.println("Digite o nome do primeiro time:");
        time1 = teclado.nextInt();
        System.out.println("Digite o nome do segundo time:");
        time2 = teclado.nextInt();
        System.out.println("Digite o numero de gols do primeiro time:");
        gol1= teclado.nextInt();
        System.out.println("Digite o numero de gols do segundo time:");
        gol2 = teclado.nextInt();
        
        if (gol1 > gol2) {
            System.out.println("O time vencedor e " + time1);
        } else {
            if (gol2 > gol1) {
                System.out.println("O time vencedor e " + time2);
            } else {
                System.out.println("Houve um empate");
            }
        }
    }
    
}
