
package numeros.doidos;
import java.util.Scanner;
public class NumerosDoidos {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double num, media;
        double acum = 0, cont = 0;
        
        do {
            System.out.println("digite um numero");
            num = teclado.nextDouble();
            acum = (acum + num);
            if (num != 0) {
                cont ++;
            }
        } while ( num != 0);
        
        media = acum / (cont + .0);
        System.out.println("A media e " + media);
    }
    
}
