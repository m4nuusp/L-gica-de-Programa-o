
package divisivel.pkg5ou7;


import java.util.Scanner;
public class Divisivel5ou7 {

 
    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    int N;
        System.out.println("Digite um numero");
        N = teclado.nextInt();
        if (N % 5 == 0 || N % 7 == 0) {
            System.out.println("Divisivel por 5 ou por 7."); 
        } else {
            System.out.println("Nao divisivel por 5 e nem por 7.");
        }
    
    }
}

