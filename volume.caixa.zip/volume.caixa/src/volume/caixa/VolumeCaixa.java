package volume.caixa;

import java.util.Scanner;

public class VolumeCaixa {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double Comp, Larg, Altu, Volu;
        System.out.println("Digite o valor do Comprimento:");
        Comp = teclado.nextDouble();
        System.out.println("Digite o valor da Altura:");
        Altu = teclado.nextDouble();
        System.out.println("Digite o valor da Largura:");
        Larg = teclado.nextDouble();

        Volu = Comp * Larg * Altu;
        System.out.println("O volume da caixa é " + Volu);
    }
    
}
