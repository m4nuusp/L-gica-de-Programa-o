package num.maior;

import java.util.Scanner;
       
public class NumMaior {

   
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num1, num2;
        System.out.println("dIGITE O PRIMEIRO NÚMERO:");
        num1 = teclado.nextInt();
        System.out.println("digite o segundo nùmero:");
        num2 = teclado.nextInt();
        
        if (num1> num2) {
            System.out.println("o maior numero é " + num1);
        } else {
            System.out.println("o maior numero é " + num2);
        }
                
    }
    
}
