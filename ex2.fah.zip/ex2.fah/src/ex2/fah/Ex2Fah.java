
package ex2.fah;

import java.util.Scanner;
public class Ex2Fah {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double TempF, Resp;
              System.out.println("Digite a temperatura em fahrenheit:");
              TempF = teclado.nextDouble();
              Resp = (TempF - 32) * 5/9;
              System.out.println("A temperatura em Celsius é " + Resp);
    }
    
}
