package manu.exercicio;

import java.util.Scanner;

public class ManuExercicio {

   
    public static void main(String[] args) {
       Scanner teclado = new Scanner (System.in);
       int tamanho = 5, cont = 0, posicao=0;
       int []num_vet = new int[tamanho];
       
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe um numero");
            num_vet[i] = teclado.nextInt();
        }
       
        for (int i = 0; i < tamanho; i++) {
            posicao++;
            if (num_vet[i]>50) {
                System.out.println("O numero " + num_vet[i] + " da posicao " + posicao + "e maior que 50.");  
            } else {
              cont++;  
            }
        } if (cont == tamanho) {
            System.out.println("Nao tem nenhum numero superior a 50");
        }
 
    
    }
    
}
