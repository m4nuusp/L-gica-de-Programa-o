package exercicio.pkg22;

import java.util.Scanner;

public class Exercicio22 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int i;
        double a, b, c;

        System.out.println("digite o valor de a:");
        a = teclado.nextDouble();
        System.out.println("digite o valor de b:");
        b = teclado.nextDouble();
        System.out.println("digite o valor de c:");
        c = teclado.nextDouble();

        System.out.println("Dgite 1 para mostrar os numeros em ordem crescente, 2 para decrescente e 3 para o maior entre a, b, c fique dentre os dois");
        i = teclado.nextInt();

        if (i == 1) {

            if (a > b) {
                if (b > c) {
                    System.out.println("a ordem decrescente e" + c + "," + b + "," + a);
                } else {
                    if (a > c) {
                        System.out.println("a ordem decrescente e" + b + "," + c + "," + a);
                    } else {
                        System.out.println("a ordem decrescente e" + b + "," + a + "," + c);
                    }
                }
            } else {
                if (a > c) {
                    System.out.println("a ordem decrescente e" + c + "," + a + "," + b);
                } else {
                    if (b > c) {
                        System.out.println("a ordem decrescente e" + a + "," + c + "," + b);
                    } else {
                        System.out.println("a ordem decrescente e" + a + "," + b + "," + c);
                    }
                }
            }
        } else {
            if (i == 2) {
                if (a < b) {
                    if (b < c) {
                        System.out.println("a ordem decrescente e" + c + "," + b + "," + a);
                    } else {
                        if (a < c) {
                            System.out.println("a ordem decrescente e" + b + "," + c + "," + a);
                        } else {
                            System.out.println("a ordem decrescente e" + b + "," + a + "," + c);
                        }
                    }
                } else {
                    if (a < c) {
                        System.out.println("a ordem decrescente e" + c + "," + a + "," + b);
                    } else {
                        if (b < c) {
                            System.out.println("a ordem decrescente e" + a + "," + c + "," + b);
                        } else {
                            System.out.println("a ordem decrescente e" + a + "," + b + "," + c);
                        }
                    }
                }
            } else {
                if (i == 3) {
                    if (a > b) {
                        if (b > c) {
                            System.out.println("a ordem e" + c + "," + a + "," + b);
                        } else {
                            if (a > c) {
                                System.out.println("a ordem e" + b + "," + a + "," + c);
                            } else {
                                System.out.println("a ordem e" + b + "," + c + "," + a);
                            }
                        }
                    } else {
                        if (a > c) {
                            System.out.println("a ordem e" + c + "," + b + "," + a);
                        } else {
                            if (b > c) {
                                System.out.println("a ordem e" + a + "," + b + "," + c);
                            } else {
                                System.out.println("a ordem e" + a + "," + c + "," + b);
                            }
                        }
                    }

                }
            }
        }
    }
}

