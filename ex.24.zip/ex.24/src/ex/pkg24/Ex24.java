
package ex.pkg24;
import java.util.Scanner;
public class Ex24 {

    
    public static void main(String[] args) {
      Scanner teclado = new Scanner (System.in);
      
      int quantidade;
      double total;
      
        System.out.println("Digite a quantidade de maças compradas:");
        quantidade = teclado.nextInt();
        
        if (quantidade < 12) {
            total = quantidade * 1.30;
            System.out.println("O valor total e" + total);
        } else {
            total = quantidade;
            System.out.println("O valor total e" + total);
        }
    }
    
}
