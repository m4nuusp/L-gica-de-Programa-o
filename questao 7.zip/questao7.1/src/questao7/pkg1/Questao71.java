
package questao7.pkg1;
import java.util.Scanner;
public class Questao71 {

   
    public static void main(String[] args) {
      Scanner teclado = new Scanner(System.in);
        //7) Faça um programa que leia um valor inteiro e positivo, calcule e mostre o valor de E, conforme a fórmula a seguir: E = 1 + 10/1! + 20/2! + 30/3! +40/4! + 50/5! + ... + 10*N/N!
        int valor, limite = 1, num1 = 1, num2 = 2, resultado = 0;
        double div = 0, valordeE = 0, dezena = 10, E = 1;

        System.out.println("informe um valor inteiro e positivo");
        valor = teclado.nextInt();

        while (limite <= valor) {

            if (limite == 1) {
                resultado = num1;
                num1 = resultado;
                div = dezena / resultado;
                valordeE = div + E;
                if (E == 1) {
                    E--;
                }
                E += valordeE;
                dezena = dezena + 10;
                limite++;
            } else {
                resultado = num1 * num2;
                num2++;
                num1 = resultado;
                div = dezena / resultado;
                valordeE = div + E;
                E = valordeE;
                dezena = dezena + 10;
                limite++;
            }

        }

        System.out.println("o valor de E e: " + valordeE);

    }
    
}
