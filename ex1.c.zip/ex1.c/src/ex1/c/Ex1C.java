package ex1.c;

import java.util.Scanner;

public class Ex1C {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double TempC, Resposta;
        System.out.println("Digite a temperatura em Celsius:");
        TempC = teclado.nextDouble();
        Resposta = (9 * TempC + 160)/5;
        System.out.println("A temperatura em fahrenheit é " + Resposta);
    }

}
