
package divisivel.pkg2ou3;

import java.util.Scanner;
public class Divisivel2ou3 {

   
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int N;
        System.out.println("Digite um número.");
        N = teclado.nextInt();
        if (N % 2 == 0 && N % 3 ==0) {
            System.out.println("O número é divisivel por 2 e por 3.");
        } else  {
            System.out.println("O numero não e divisivel por 2 e por 3");
        }
    }
    
}
