package exercicio.pkg19;

import java.util.Scanner;

public class Exercicio19 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int a, b, c;

        System.out.println("Digite o valor de a:");
        a = teclado.nextInt();
        System.out.println("Digite o valor de b:");
        b = teclado.nextInt();
        System.out.println("Digite o valor de c:");
        c = teclado.nextInt();

        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("E um triangulo.");
        } else {
            System.out.println("Nao e um triangulo.");
        }
    }

}
