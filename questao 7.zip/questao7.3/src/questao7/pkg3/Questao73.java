package questao7.pkg3;

import java.util.Scanner;

public class Questao73 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int valor, limite, num1 = 1, num2 = 2, resultado = 0;
        double div = 0, valordeE = 0, dezena = 10, E = 1;

        System.out.println("informe um valor inteiro e positivo");
        valor = teclado.nextInt();

        for (limite = 1; limite <= valor; limite++) {

            if (limite == 1) {
                resultado = num1;
                num1 = resultado;
                div = dezena / resultado;
                valordeE = div + E;
                if (E == 1) {
                    E--;
                }
                E += valordeE;
                dezena = dezena + 10;

            } else {
                resultado = num1 * num2;
                num2++;
                num1 = resultado;
                div = dezena / resultado;
                valordeE = div + E;
                E = valordeE;
                dezena = dezena + 10;

            }

        }

        System.out.println("o valor de E e: " + valordeE);

    }

}
