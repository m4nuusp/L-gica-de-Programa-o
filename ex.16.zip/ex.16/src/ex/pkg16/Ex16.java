package ex.pkg16;

import java.util.Scanner;

public class Ex16 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double preco;
        int codigo, quantidade;
        System.out.println("Insira o codigo");
        codigo = teclado.nextInt();
        System.out.println("Insira a quantidade");
        quantidade = teclado.nextInt();
        if (codigo == 5) {
            preco = 32 * quantidade;
            System.out.println("Preço Total:" + preco);
        } else {
            if (codigo == 6) {
                preco = 45 * quantidade;
                System.out.println("Preço Total:" + preco);
            } else {
                if (codigo == 2) {
                    preco = 37 * quantidade;
                    System.out.println("Preço Total:" + preco);
                } else {
                    if (codigo == 12) {
                        preco = 44 * quantidade;
                        System.out.println("Preço Total:" + preco);
                    } else {
                        System.out.println("codigo invalido");

                    }
                }
            }
        }
    }

}
