package ex.pkg12;

import java.util.Scanner;

public class Ex12 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int num, resto;
        System.out.println("Digite um número:");
        num = teclado.nextInt();
        resto = num % 2;
        if (resto == 0) {
            if (num > 0) {
                System.out.println("O número e par e positivo.");
            } else {
                System.out.println("O número e par e negativo");
            }

        } else {
            if (num > 0) {
                System.out.println("O número e impar e positivo");
            } else {
                System.out.println("O número e impar e negativo");
            }
        }
    }

}
