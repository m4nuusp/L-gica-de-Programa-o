
package tabuada.pkg0a10;


public class Tabuada0a10 {

    public static void main(String[] args) {
        int num = 0, cont = 0, resultado;
        while (cont <=10) {     
            
            resultado = cont * num;
            System.out.println(num + " x " + cont + "=" + resultado);
            cont ++;
        }
        while (num == 0) {            
            num ++;
        }
    }
    
}
