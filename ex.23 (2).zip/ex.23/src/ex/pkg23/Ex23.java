package ex.pkg23;

import java.util.Scanner;

public class Ex23 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int hora_ini, hora_fim, minutos_ini, minutos_fim,
                duracao_horas, duracao_minutos;
        System.out.println("Digite a hora inicial");
        hora_ini = teclado.nextInt();
        System.out.println("digite o minuto inicial");
        minutos_ini = teclado.nextInt();
        System.out.println("digite a hora final");
        hora_fim = teclado.nextInt();
        System.out.println("Digite o minuto final");
        minutos_fim = teclado.nextInt();

        if (hora_ini < hora_fim) {
            if (minutos_ini < minutos_fim) {
                duracao_horas = hora_fim - hora_ini;
                duracao_minutos = minutos_ini - minutos_fim;
                System.out.println("O tempo de duaração do jogo foi de :" + duracao_horas + ":" + "horas" + duracao_minutos + "minuto;");
            } else {
                duracao_horas = (hora_fim + hora_ini) - 1;
                duracao_minutos = (minutos_fim + 60) - minutos_ini;
                System.out.println("O tempo de duaração do jogo foi de :" + duracao_horas + ":" + "horas" + duracao_minutos + "minuto;");
            }
        } else {
            if (minutos_ini < minutos_fim) {
                duracao_horas = (hora_fim - 24) - hora_ini;
                duracao_minutos = minutos_ini + minutos_fim;
                System.out.println("O tempo de duaração do jogo foi de :" + duracao_horas + ":" + "horas" + duracao_minutos + "minuto;");
            } else {
                duracao_horas = (hora_fim + hora_ini) - 1;
                duracao_minutos = (minutos_fim + 60) - minutos_ini;
                System.out.println("O tempo de duaração do jogo foi de :" + duracao_horas + ":" + "horas" + duracao_minutos + "minuto;");
            }
        }
    }

}
