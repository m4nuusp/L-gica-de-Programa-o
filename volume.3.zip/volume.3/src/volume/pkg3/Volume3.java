
package volume.pkg3;

import java.util.Scanner;
public class Volume3 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double Raio, Al, Vol;
        System.out.println("Digite o valor do raio:");
        Raio = teclado.nextDouble();
        System.out.println("Digite o valor da altura:");
        Al = teclado.nextDouble();
       Vol = 3.14159 * Raio * Raio * Al;
        System.out.println("O volume da lata de óleo é " + Vol);
    }
    
}
