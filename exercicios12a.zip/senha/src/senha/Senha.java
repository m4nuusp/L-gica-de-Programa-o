package senha;

import java.util.Scanner;

public class Senha {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int senha = 1606, tentativasenha;

        do {
            System.out.println("Digite sua senha");
            tentativasenha = teclado.nextInt();

        } while (senha != tentativasenha);

        System.out.println("Senha correta");

    }

}
