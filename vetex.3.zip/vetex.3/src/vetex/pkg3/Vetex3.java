package vetex.pkg3;

import java.util.Scanner;

public class Vetex3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
       int []vetnum = new int[9];
     
        
        for (int i = 0; i < 9; i++) {
            System.out.println("Digite um numero");
            vetnum[i] = teclado.nextInt();
            
            int numatual = vetnum[i];
             int divisores = 0;
            
            if (numatual <=1) {
                divisores = 1;
            } else {
                for (int j = 2; j < numatual; j++) {
                    if (numatual % j ==0) {
                        divisores ++;
                    }
                }
            }
           
            if (divisores ==0) {
                System.out.println(numatual +" e primo");
            } else  {
                System.out.println(numatual +" nao e primo");
            }
            
        } 
    }

}
