
package vetex.pkg2;

import java.util.Scanner;
public class Vetex2 {

   
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int[] vet_num = new int[10];
        
        for (int i = 0; i < 10; i++) {
            System.out.println("Digite um numero");
            vet_num[i] = teclado.nextInt();
        } for (int i = 0; i < 10; i++) {
            if (vet_num[i]>50) {
            System.out.println( "os numeros superiores a 50 sao " + vet_num[i]);
        } 
            }for (int i = 0; i < 10; i++) {
            if (vet_num[i]<50) {
                System.out.println( vet_num[i] +"Nao tem numeros majores que 50");
        }
            }
    }
}
    
    
