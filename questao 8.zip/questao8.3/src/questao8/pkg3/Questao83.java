
package questao8.pkg3;

import java.util.Scanner;
public class Questao83 {

    
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       //8) Faça um programa para auxiliar um time de Futebol de campo.
        int jogadores, limite;
        double idade, mediamaiores = 0, menoresidade = 0, peso, altura, alturamedia = 0, jogadores80 = 0, porcentagem80, altura1 = 0, altura2 = 0, altura3 = 0;
        String nome, alto1 = "", alto2 = "", alto3 = "";

        System.out.println("quantos jogadores temos no time?");
        jogadores = teclado.nextInt();

        teclado.nextLine();

        for (limite = 1; limite <= jogadores; limite++) {
            System.out.println("informe seu nome");
            nome = teclado.nextLine();

            System.out.println("informe sua idade");
            idade = teclado.nextDouble();

            if (idade < 18) {
                menoresidade++;
            } else {

                mediamaiores += idade;

            }

            System.out.println("informe seu peso");
            peso = teclado.nextDouble();

            if (peso > 80) {

                jogadores80++;

            }

            System.out.println("informe sua altura em metros");
            altura = teclado.nextDouble();
            alturamedia += altura;

            if (altura > altura1) {

                altura3 = altura2;
                alto3 = alto2;

                altura2 = altura1;
                alto2 = alto1;

                altura1 = altura;
                alto1 = nome;

            } else if (altura > altura2) {

                altura3 = altura2;
                alto3 = alto2;

                altura2 = altura;
                alto2 = nome;

            } else if (altura > altura3) {

                altura3 = altura;
                alto3 = nome;
            }

            teclado.nextLine();

        }

        alturamedia = alturamedia / jogadores;
        if (jogadores == 2) {
            mediamaiores = mediamaiores;
        } else {
            mediamaiores = mediamaiores / jogadores;
        }
        porcentagem80 = (jogadores80 / jogadores) * 100;

        System.out.println("no time ha " + menoresidade + " jogadores menores de idade ");
        System.out.println("A media de idade entre os maiores de idade e de " + mediamaiores + " anos");
        System.out.println("A altura média do time e de " + alturamedia + "m");
        System.out.println(porcentagem80 + "% dos jogadores do time tem mais de 80kg");
        System.out.println("1º Mais alto: " + alto1 + " (" + altura1 + "m)");
        System.out.println("2º Mais alto: " + alto2 + " (" + altura2 + "m)");
        System.out.println("3º Mais alto: " + alto3 + " (" + altura3 + "m)");

    }
    
}
