
package vetex.pkg4;

import java.util.Scanner;

public class Vetex4 {

   
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        String [] vetanimais = new String [5];
        String [] vetfrutas = new String [5];
        String [] vetjuncao = new String [10];
        int cont=0, i=0, j=0;
        
        for (int m = 0; m < 5; m++) {
            System.out.println("Digite um animal");
            vetanimais[m] = teclado.nextLine();
            System.out.println("Digite uma fruta");
            vetfrutas[m] = teclado.nextLine();
        } while (cont<10) {
         vetjuncao[cont] = vetanimais[i];    
         i++;
         cont++;
         vetjuncao[cont] = vetfrutas[j];
            j++;
            cont++;
        }
        cont =0;
        while (cont<10) {            
            System.out.println(vetjuncao[cont]);
            cont++;
        }
    }
    
}
