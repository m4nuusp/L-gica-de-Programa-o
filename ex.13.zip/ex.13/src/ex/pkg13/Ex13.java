package ex.pkg13;

import java.util.Scanner;

public class Ex13 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int opcao;
        double n1, n2, n3, media;
        System.out.println("Digite a primeira nota");
        n1 = teclado.nextDouble();
        System.out.println("Digite a segunda nota");
        n2 = teclado.nextDouble();
        System.out.println("Digite a terceira nota");
        n3 = teclado.nextDouble();
        System.out.println("Se voce deseja calcular sua media na forma aritimetica, digite 1, caso deseja calcular ela como ponderada, digite 2");
        opcao = teclado.nextInt();
        if (opcao == 1) {
            media = (n1 + n2 + n3) / 3;
            System.out.println("Media " + media);
        } else {
            media = (n1 * 3 + n2 * 3 + n3 * 4) / (3 + 3 + 4);
            System.out.println("Media " + media);
        }
    }

}
