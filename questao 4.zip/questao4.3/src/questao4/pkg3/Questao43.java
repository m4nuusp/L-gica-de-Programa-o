
package questao4.pkg3;
import java.util.Scanner;
public class Questao43 {

   
    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       //4) Informe o fatorial de um informado pelo usuário. Fatorial é o resultado da multiplicação dos números inteiros entre 1 e o próprio número informado.
    int fat,limite=1,mult=1,resultado=0,numero=1,acumulador=1;
   
    
        System.out.println("informe um numero para apresentar seu fatorial");
        fat= teclado.nextInt();
        
        for (limite=1;limite<=fat;limite++){
            
        acumulador=acumulador*mult;
           mult++;
        }
        
        System.out.println("seu fatorial eh: "+acumulador);
        
    
    }
    
}
