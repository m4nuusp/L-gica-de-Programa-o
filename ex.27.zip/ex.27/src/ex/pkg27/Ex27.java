package ex.pkg27;

import java.util.Scanner;

public class Ex27 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double nota1, nota2, nota3, MA, ME;
        int numin;
        System.out.println("Digite a nota 1");
        nota1 = teclado.nextDouble();
        System.out.println("Digite a nota 2");
        nota2 = teclado.nextDouble();
        System.out.println("Digite a nota 3");
        nota3 = teclado.nextDouble();
        System.out.println("Digite a media dos exercicios");
        ME = teclado.nextDouble();
        System.out.println("Digite o numero de indentificvaçao do aluno");
        numin = teclado.nextInt();

        MA = (nota1 + nota2 * 2 + nota3 * 3 + ME) / 7;
        if (MA >= 9) {
            System.out.println("O aluno " + numin + "foi aprovado");
        } else {
            if (MA >= 7.5 && MA < 9) {
                System.out.println("O aluno " + numin + "foi aprovado");
            } else {
                if (MA >= 6 && MA < 7.5) {
                    System.out.println("O aluno " + numin + "foi aprovado");
                } else {
                    if (MA >= 4 && MA < 6) {
                        System.out.println("O aluno " + numin + "foi reprovado");
                    } else {
                        System.out.println("O aluno " + numin + "foi reprovado");
                    }
                }
            }
        }

    }

}
