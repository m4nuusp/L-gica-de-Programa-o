
package questao6.pkg3;

import java.util.Scanner;

public class Questao63 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //6) Faça um programa onde o usuário informa um número. Classifique esse número como primo ou Não Primo. Um número é primo se, e somente se, for divisível de forma inteira exata apenas por um e por ele mesmo.
        int num, div = 0;

        System.out.println("informe um numero");
        num = teclado.nextInt();

        div = num;
       

        for(div=div-1;div<num&&div>1;div--){

            if (num % div == 0 && div != num) {

                num = 14;
            }

            div--;

        }

        if (num != 14) {
            System.out.println("o numero e primo");
        }

        if (num == 14) {
            System.out.println("o numero nao e primo");
        }

    }
    
}
