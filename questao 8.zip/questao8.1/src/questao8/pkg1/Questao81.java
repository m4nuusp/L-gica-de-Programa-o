package questao8.pkg1;

import java.util.Scanner;

public class Questao81 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //8) Faça um programa para auxiliar um time de Futebol de campo.
        int jogadores, limite = 1;
        double idade, medmaior = 0, menoridade = 0, peso, alt, altmedia = 0, jogadores80 = 0, porcentagem80, alt1 = 0, alt2 = 0, alt3 = 0;
        String nome, alto1 = "", alto2 = "", alto3 = "";

        System.out.println("quantos jogadores temos no time?");
        jogadores = teclado.nextInt();

        teclado.nextLine();

        while (limite <= jogadores) {
            System.out.println("informe seu nome");
            nome = teclado.nextLine();

            System.out.println("informe sua idade");
            idade = teclado.nextDouble();

            if (idade < 18) {
                menoridade++;
            } else {

                medmaior += idade;

            }

            System.out.println("informe seu peso");
            peso = teclado.nextDouble();

            if (peso > 80) {

                jogadores80++;

            }

            System.out.println("informe sua altura em metros");
            alt = teclado.nextDouble();
            altmedia += alt;

            if (alt > alt1) {

                alt3 = alt2;
                alto3 = alto2;

                alt2 = alt1;
                alto2 = alto1;

                alt1 = alt;
                alto1 = nome;

            } else if (alt > alt2) {

                alt3 = alt2;
                alto3 = alto2;

                alt2 = alt;
                alto2 = nome;

            } else if (alt > alt3) {

                alt3 = alt;
                alto3 = nome;
            }

            limite++;

            teclado.nextLine();

        }

        altmedia = altmedia / jogadores;
        if (jogadores == 2) {
            medmaior = medmaior;
        } else {
            medmaior = medmaior / jogadores;
        }
        porcentagem80 = (jogadores80 / jogadores) * 100;

        System.out.println("no time ha " + menoridade + " jogadores menores de idade ");
        System.out.println("A media de idade entre os maiores de idade e de " + medmaior + " anos");
        System.out.println("A altura média do time e de " + altmedia + "m");
        System.out.println(porcentagem80 + "% dos jogadores do time tem mais de 80kg");
        System.out.println("1º Mais alto: " + alto1 + " (" + alt1 + "m)");
        System.out.println("2º Mais alto: " + alto2 + " (" + alt2 + "m)");
        System.out.println("3º Mais alto: " + alto3 + " (" + alt3 + "m)");

    }

}
