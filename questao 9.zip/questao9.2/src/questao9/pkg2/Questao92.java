package questao9.pkg2;

import java.util.Scanner;

public class Questao92 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        //9) Faça um programa para auxiliar uma cantina.
        int registro, limite = 0, opção;
        double valorestotais = 0, totalvenda, quantidade, troco, valorpago;
        char escolha;

        do {

            System.out.println("Menu de opcoes:");
            System.out.println("digite 1 para registrar a venda de um produto");
            System.out.println("digite 2 para apresentar o total e calcular o troco");
            System.out.println("digite 3 para sair");
            opção = teclado.nextInt();

            if (opção == 1) {

                System.out.println("Produtos a venda:");
                System.out.println("digite A para Água - 3,50RS");
                System.out.println("digite B para salgado - 5,00RS");
                System.out.println("digite C para salada de fruta - 7,00RS");
                escolha = teclado.next().charAt(0);
                teclado.nextLine();
                System.out.println("digite a quantidade de produtos");
                quantidade = teclado.nextDouble();

                if (escolha == 'A') {

                    totalvenda = quantidade * 3.5;
                    valorestotais += totalvenda;
                    totalvenda = totalvenda - totalvenda;

                } else if (escolha == 'B') {
                    totalvenda = quantidade * 5;
                    valorestotais += totalvenda;
                    totalvenda = totalvenda - totalvenda;
                } else if (escolha == 'C') {
                    totalvenda = quantidade * 7;
                    valorestotais += totalvenda;
                    totalvenda = totalvenda - totalvenda;

                }
            }

            if (opção == 2) {

                System.out.println("total da venda: " + valorestotais);

                System.out.println("digite o valor que deseja pagar (aceitamos apenas valores maiores ou iguais ao total da compra)");
                valorpago = teclado.nextDouble();

                troco = valorpago - valorestotais;

                System.out.println("seu troco e  de: " + troco + "RS");

                valorestotais = valorestotais - valorestotais;

            }

            if (opção == 3) {

                limite = limite + 500;

            }

        } while (limite < 1);

        System.out.println("Obrigado pela sua compra!");

    }

}
