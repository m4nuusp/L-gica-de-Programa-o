package vetex.pkg7;

import java.util.Scanner;

public class Vetex7 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        
        int tamanho = 5;
        String []nomefuncionarios = new String[tamanho];
        double    []salariofuncionario = new double[tamanho];
        int    []temposervico = new int[tamanho];
        double salarionovo;
        
        for (int i = 0; i < tamanho; i++) {
            System.out.println("Informe o nome do funcionario");
            nomefuncionarios[i] = teclado.nextLine();
            System.out.println("Informe o salario que esse funcionario recebe");
            salariofuncionario[i] = teclado.nextDouble();
            System.out.println("Informe o tempo de servico desse funcionario");
            temposervico[i] = teclado.nextInt();
             teclado.nextLine();
        }
        for (int i = 0; i < tamanho; i++) {
            if (salariofuncionario[i]>1940.0 && temposervico[i]<5) {
                System.out.println("O funcionario " + nomefuncionarios[i] + " nao recebera aumento.");
            }
        }
        for (int i = 0; i < tamanho; i++) {
            if (salariofuncionario[i]<1940.0 && temposervico[i]>5) {
                salarionovo = salariofuncionario[i] + (salariofuncionario[i] * 0.35);
                System.out.println("O funcionario " + nomefuncionarios[i] + " tem o salario novo de " + salarionovo);
            } else {
                if (temposervico[i]>5) {
                    salarionovo = salariofuncionario[i] + (salariofuncionario[i] * 0.25);
                     System.out.println("O funcionario " + nomefuncionarios[i] + " tem o salario novo de " + salarionovo);
                } else {
                    if (salariofuncionario[i]<1940.0) {
                         salarionovo = salariofuncionario[i] + (salariofuncionario[i] * 0.15);
                         System.out.println("O funcionario " + nomefuncionarios[i] + " tem o salario novo de " + salarionovo);
                    }
                }
            }
        }
        
        
        
        
    }

}
