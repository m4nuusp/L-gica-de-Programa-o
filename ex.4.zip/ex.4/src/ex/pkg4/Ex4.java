
package ex.pkg4;

import java.util.Scanner;
public class Ex4 {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double A, B, Temp;
        System.out.println("Digite o valor de A:");
        A = teclado.nextDouble();
        System.out.println("Digite o valor de B");
        B = teclado.nextDouble();
        Temp = A;
        A = B;
        B = Temp;
        System.out.println("Agora A vale B" + B );
        System.out.println("e B vale A " + A);
    }
    
}
