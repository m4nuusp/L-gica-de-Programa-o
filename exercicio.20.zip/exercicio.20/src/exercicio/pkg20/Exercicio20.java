package exercicio.pkg20;

import java.util.Scanner;

public class Exercicio20 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int valor, valorOriginal, notas100, notas50, notas10, notas5, notas1;

        System.out.println("Digite o valor");
        valorOriginal = teclado.nextInt();

        valor = valorOriginal;

        notas100 = valorOriginal / 100;
        valor = valorOriginal % 100;
        notas50 = valor / 50;
        valor = valor % 50;
        notas10 = valor / 10;
        valor = valor % 10;
        notas5 = valor / 5;
        valor = valor % 5;
        notas1 = valor / 1;
        valor = valor % 1;
        
        System.out.println("O total de notas e: notas de 100: " + notas100 + "notas de 50: " + notas50 + "notas de 10: " + notas10 + "notas de 5: " + notas5 + "notas de 1: " + notas1);
    }

}
